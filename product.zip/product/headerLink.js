/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var headerLink = '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">'+
    '<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">'+
    '<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">'+
    '<link rel="stylesheet" href="css/elegant-icons.css" type="text/css">'+
    '<link rel="stylesheet" href="css/nice-select.css" type="text/css">'+
    '<link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">'+
    '<link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">'+
    '<link rel="stylesheet" href="css/slicknav.min.css" type="text/css">'+
    '<link rel="stylesheet" href="css/style.css" type="text/css">'+
    
    '<script src="../js/alertifyjs/alertify.js" type="text/javascript"></script>'+
    '<link href="../js/alertifyjs/css/alertify.css" rel="stylesheet" type="text/css">'+
    '<link href="../js/alertifyjs/css/themes/default.css" rel="stylesheet" type="text/css">';
document.write(headerLink);

