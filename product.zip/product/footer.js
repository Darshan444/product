/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var footerdata = '<footer class="footer spad">'+
        '<div class="container">'+
            '<div class="row">'+
                '<div class="col-lg-12">'+
                    '<div class="footer__copyright">'+
                        '<div class="footer__copyright__text"><p> Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made </p></div>'+
                        '<div class="footer__copyright__payment"><img src="../img/lithe-logo.png" alt=""></div>'+
                    '</div>'+
                '</div>'+
            '</div>'+
        '</div>'+
    '</footer>';
document.write(footerdata);

var footerLink = '<script src="js/jquery-3.3.1.min.js"></script>'+
    '<script src="js/bootstrap.min.js"></script>'+
    '<script src="js/jquery.nice-select.min.js"></script>'+
    '<script src="js/jquery-ui.min.js"></script>'+
    '<script src="js/jquery.slicknav.js"></script>'+
    '<script src="js/mixitup.min.js"></script>'+
    '<script src="js/owl.carousel.min.js"></script>'+
    '<script src="js/main.js"></script>'+

    '<script src="controller.js"></script>';
document.write(footerLink);